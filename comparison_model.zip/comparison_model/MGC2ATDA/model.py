import torch
from torch import nn
import numpy as np
import torch.nn.functional as F
from torch_geometric.nn import dense, norm

class GraphAttentionLayer(nn.Module):
    """
    Simple GAT layer, similar to https://arxiv.org/abs/1710.10903
    """

    def __init__(self, in_features, out_features, dropout, alpha):
        super(GraphAttentionLayer, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha

        self.W = nn.Parameter(torch.empty(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.empty(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, h, adj):
        Wh = torch.mm(h, self.W)
        # h.shape: (N, in_features), Wh.shape: (N, out_features)
        e = self._prepare_attentional_mechanism_input(Wh)

        zero_vec = -9e15 * torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        attention = F.softmax(attention, dim=1)
        attention = F.dropout(attention, self.dropout, training=self.training)
        h_prime = torch.matmul(attention, Wh)

        # if self.concat:
        #     return F.elu(h_prime)
        # else:
        #     return h_prime
        return F.elu(h_prime)

    def _prepare_attentional_mechanism_input(self, Wh):
        # Wh.shape (N, out_feature)
        # self.a.shape (2 * out_feature, 1)
        # Wh1&2.shape (N, 1)
        # e.shape (N, N)
        Wh1 = torch.matmul(Wh, self.a[: self.out_features, :])
        Wh2 = torch.matmul(Wh, self.a[self.out_features :, :])
        # broadcast add
        e = Wh1 + Wh2.T
        return self.leakyrelu(e)

    def __repr__(self):
        return (
            self.__class__.__name__
            + " ("
            + str(self.in_features)
            + " -> "
            + str(self.out_features)
            + ")"
        )


class GAT(nn.Module):
    def __init__(
        self,
        p_feat_dim,
        d_feat_dim,
        hidden_dim,
        out_dim,
        dropout,
        alpha,
        nheads,
    ):
        # def __init__(self, nfeat, nhid_per_head, out_d, dropout, alpha, nheads):
        """Dense version of GAT."""
        super(GAT, self).__init__()
        self.dropout = dropout
        self.bn_p = nn.BatchNorm1d(p_feat_dim)
        self.bn_d = nn.BatchNorm1d(d_feat_dim)
        self.linear_p = nn.Linear(p_feat_dim, hidden_dim)
        self.linear_d = nn.Linear(d_feat_dim, hidden_dim)
        assert out_dim % nheads == 0
        nhid_per_head = int(out_dim / nheads)
        self.layer1 = [
            GraphAttentionLayer(hidden_dim, nhid_per_head, dropout=dropout, alpha=alpha)
            for _ in range(nheads)
        ]
        for i, head in enumerate(self.layer1):
            self.add_module("layer1_head_{}".format(i), head)

        # self.layer2 = [
        #     GraphAttentionLayer(
        #         nhid_per_head * nheads, nhid_per_head, dropout=dropout, alpha=alpha
        #     )
        #     for _ in range(nheads)
        # ]
        # for i, head in enumerate(self.layer2):
        #     self.add_module("lay2_head_{}".format(i), head)

        self.out_att = GraphAttentionLayer(
            nhid_per_head * nheads, out_dim, dropout=dropout, alpha=alpha
        )

    def forward(self, p_feat, d_feat, adj):
        p_feat_hidden = self.linear_p(self.bn_p(p_feat))
        d_feat_hidden = self.linear_d(self.bn_d(d_feat))
        x = torch.cat((p_feat_hidden, d_feat_hidden), dim=0)

        x = F.dropout(x, self.dropout, training=self.training)
        x = torch.cat([att(x, adj) for att in self.layer1], dim=1)

        # x = F.dropout(x, self.dropout, training=self.training)
        # x = torch.cat([att(x, adj) for att in self.layer2], dim=1)

        x = F.dropout(x, self.dropout, training=self.training)
        x = self.out_att(x, adj)
        p_feat = x[: p_feat.shape[0], :]
        d_feat = x[p_feat.shape[0] :, :]
        return p_feat, d_feat


class PositionWiseFFN(nn.Module):
    def __init__(self, ffn_num_input, ffn_num_hiddens, ffn_num_outputs, **kwargs):
        super(PositionWiseFFN, self).__init__(**kwargs)
        self.dense1 = nn.Linear(ffn_num_input, ffn_num_hiddens)
        self.relu = nn.ReLU()
        self.dense2 = nn.Linear(ffn_num_hiddens, ffn_num_outputs)

    def forward(self, X):
        return self.dense2(self.relu(self.dense1(X)))


# @save
class AddNorm(nn.Module):
    def __init__(self, normalized_shape, dropout, **kwargs):
        super(AddNorm, self).__init__(**kwargs)
        self.dropout = nn.Dropout(dropout)
        self.ln = nn.LayerNorm(normalized_shape)

    def forward(self, X, Y):
        return self.ln(self.dropout(Y) + X)


def transpose_qkv(X, num_heads):
    X = X.reshape(X.shape[0], num_heads, -1)
    X = X.permute(1, 0, 2)
    return X


def transpose_output(X, num_heads):
    """Reverse the operation of `transpose_qkv`.

    Defined in :numref:`sec_multihead-attention`"""
    X = X.permute(1, 0, 2)
    return X.reshape(X.shape[0], -1)


def sequence_mask(X, valid_len, value=0):
    """Mask irrelevant entries in sequences.

    Defined in :numref:`sec_seq2seq_decoder`"""
    maxlen = X.size(1)
    mask = (
        torch.arange((maxlen), dtype=torch.float32, device=X.device)[None, :]
        < valid_len[:, None]
    )
    X[~mask] = value
    return X


class DotProductAttention(nn.Module):
    def __init__(self, dropout, **kwargs):
        super(DotProductAttention, self).__init__(**kwargs)
        self.dropout = nn.Dropout(dropout)

    def forward(self, Q_p, K_p, V_p):
        d = Q_p.shape[-1]
        scores = torch.bmm(Q_p, K_p.transpose(1, 2)) / np.sqrt(d)
        self.attention_weights = nn.functional.softmax(scores, dim=-1)
        return torch.bmm(self.dropout(self.attention_weights), V_p)


class MultiHeadAttention(nn.Module):
    def __init__(
        self,
        q_in_dim,
        kv_in_dim,
        key_size,
        query_size,
        value_size,
        num_heads,
        dropout,
        bias=False,
        **kwargs
    ):
        super(MultiHeadAttention, self).__init__(**kwargs)
        self.num_heads = num_heads
        self.attention = DotProductAttention(dropout)
        self.W_q = nn.Linear(q_in_dim, query_size, bias=bias)
        self.W_k = nn.Linear(kv_in_dim, key_size, bias=bias)
        self.W_v = nn.Linear(kv_in_dim, value_size, bias=bias)
        self.W_o = nn.Linear(value_size, q_in_dim, bias=bias)

    def forward(self, queries, keys, values):
        Q_p = transpose_qkv(self.W_q(queries), self.num_heads)
        K_p = transpose_qkv(self.W_k(keys), self.num_heads)
        V_p = transpose_qkv(self.W_v(values), self.num_heads)
        output = self.attention(Q_p, K_p, V_p)
        output_concat = transpose_output(output, self.num_heads)
        return self.W_o(output_concat)


# @save
class EncoderBlock(nn.Module):
    def __init__(
        self,
        q_in_dim,
        kv_in_dim,
        key_size,
        query_size,
        value_size,
        ffn_num_hiddens,
        num_heads,
        dropout,
        bias=False,
        **kwargs
    ):
        super(EncoderBlock, self).__init__(**kwargs)
        self.attention = MultiHeadAttention(
            q_in_dim,
            kv_in_dim,
            key_size,
            query_size,
            value_size,
            num_heads,
            dropout,
            bias,
        )
        self.addnorm1 = AddNorm([q_in_dim], dropout)
        # self.linear = nn.Linear(key_size, key_size)
        # self.ffn = PositionWiseFFN(q_in_dim, ffn_num_hiddens, q_in_dim)
        # self.addnorm2 = AddNorm([q_in_dim], dropout)

    def forward(self, queries, keys, values):
        # return self.attention(queries, keys, values)
        # return self.addnorm1(queries, self.attention(queries, keys, values))
        Y = self.addnorm1(queries, self.attention(queries, keys, values))
        return Y
        # return self.addnorm2(Y, Y)


class Encoder(nn.Module):
    def __init__(self, **kwargs):
        super(Encoder, self).__init__(**kwargs)

    def forward(self, *args):
        raise NotImplementedError


# @save
class TransformerEncoder(Encoder):
    def __init__(
        self,
        q_in_dim,
        kv_in_dim,
        key_size,
        query_size,
        value_size,
        ffn_num_hiddens,
        num_heads,
        num_layers,
        dropout,
        bias=False,
        **kwargs
    ):
        super(TransformerEncoder, self).__init__(**kwargs)
        # self.p_emb = nn.Embedding.from_pretrained(p_feat_init, freeze=False)
        # self.d_emb = nn.Embedding.from_pretrained(d_feat_init, freeze=False)
        self.blks = nn.Sequential()
        for i in range(num_layers):
            self.blks.add_module(
                "block" + str(i),
                EncoderBlock(
                    q_in_dim,
                    kv_in_dim,
                    key_size,
                    query_size,
                    value_size,
                    ffn_num_hiddens,
                    num_heads,
                    dropout,
                    bias,
                ),
            )

    def forward(self, p_feat, d_feat, *args):
        Y = p_feat
        self.attention_weights = [None] * len(self.blks)
        for i, blk in enumerate(self.blks):
            Y = blk(Y, d_feat, d_feat)
            self.attention_weights[i] = blk.attention.attention.attention_weights
        return Y


class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / np.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):  # 这里代码做了简化如 3.2节。
        support = torch.mm(input, self.weight)  # (2708, 16) = (2708, 1433) X (1433, 16)
        output = torch.mm(adj, support)  # (2708, 16) = (2708, 2708) X (2708, 16)
        if self.bias is not None:
            return output + self.bias  # 加上偏置 (2708, 16)
        else:
            return output  # (2708, 16)

    def __repr__(self):
        return (
            self.__class__.__name__
            + " ("
            + str(self.in_features)
            + " -> "
            + str(self.out_features)
            + ")"
        )

class MultiViewAttention(nn.Module):
    '''
        a simple attention layer
        inspired by : MGAT: Multi-view Graph Attention Networks
        DOI: 10.1016/j.neunet.2020.08.021
        f
    '''   

    def __init__(self, fea_out, fea_init):
        super(MultiViewAttention,self).__init__()
        
        self.W_a = nn.Parameter(torch.rand(fea_out, fea_init)) 
        nn.init.xavier_normal_(self.W_a)
        self.v = nn.Parameter(torch.randn(1, fea_out))
        nn.init.xavier_normal_(self.v)
        
        self.fea_init = fea_init
        self.blta = 1 / np.sqrt(fea_out)
    def forward(self, Z_LD_temp,Z_LD):
        temp1 = torch.tanh(torch.matmul(self.W_a,Z_LD_temp))
        ld_temp_score = torch.mm(self.v,temp1) * self.blta      
        temp2 = torch.tanh(torch.matmul(self.W_a, Z_LD))
        ld_score = torch.mm(self.v, temp2) * self.blta 
        score = torch.cat((ld_temp_score,ld_score), dim = 0) #2,128
        alpha = F.softmax(score, dim=0)  # 2,128
        z1 = torch.zeros((self.fea_init,self.W_a.shape[0]), device=Z_LD_temp.device) 
        z2 = torch.zeros((self.fea_init,self.W_a.shape[0]), device=Z_LD_temp.device)
        for i in range(self.fea_init):
            z1[i] = torch.mul(alpha[0], Z_LD_temp[i]) 
            z2[i] = torch.mul(alpha[1], Z_LD[i])
        z_ld_att = z1 + z2 
        return z_ld_att

class GCN(nn.Module):
    def __init__(self, p_feat_dim, d_feat_dim, n_hidden, dropout):
        super(GCN, self).__init__()
        self.linear_p = nn.Linear(p_feat_dim, n_hidden)
        self.linear_d = nn.Linear(d_feat_dim, n_hidden)

        self.gc1 = GraphConvolution(n_hidden, n_hidden)
        self.dropout = dropout

    def forward(self, p_feat, d_feat, adj):
        p_feat = self.linear_p(p_feat)
        d_feat = self.linear_d(d_feat)
        x = torch.vstack((p_feat, d_feat))
        x = torch.nn.functional.relu(self.gc1(x, adj))
        x = torch.nn.functional.dropout(x, self.dropout, training=self.training)
        p_feat = x[: p_feat.shape[0], :]
        d_feat = x[p_feat.shape[0] :, :]
        return p_feat, d_feat

class GCN_sim(nn.Module):
    def __init__(self, feat_dim, n_hidden, dropout):
        super(GCN_sim, self).__init__()
        self.linear_ = nn.Linear(feat_dim, n_hidden)

        self.gc1 = GraphConvolution(n_hidden, n_hidden)
        self.dropout = dropout

    def forward(self, sim_feat, adj):
        x = self.linear_(sim_feat)
        x = torch.nn.functional.relu(self.gc1(x, adj))
        x = torch.nn.functional.dropout(x, self.dropout, training=self.training)
        return x


class Predictor(nn.Module):
    def __init__(self):
        super(Predictor, self).__init__()
        #self.linear1 = nn.Linear(128, 128)
        #self.linear2 = nn.Linear(128, 128)

    def forward(self, p_feat, d_feat):
        #res = p_feat.mm(self.linear(d_feat).t())
        #p_feat = self.linear1(p_feat)
        #d_feat = self.linear2(d_feat)
        res = p_feat.mm(d_feat.t())
        return F.sigmoid(res)


class MGC2ATDA(nn.Module):
    def __init__(self, gcn, gcn_p_sim, gcn_d_sim, MultiView_feat, p_encoder, d_encoder, predictor, **kwargs):
        super(MGC2ATDA, self).__init__(**kwargs)
        self.gcn = gcn
        self.gcn_p_sim = gcn_p_sim
        self.gcn_d_sim = gcn_d_sim
        self.Multi_feat_merge = MultiView_feat
        self.p_encoder = p_encoder
        self.d_encoder = d_encoder
        self.predictor = predictor

    def forward(self, p_simf, d_feat, adj_mat):
        p_feat_gcn, d_feat_gcn = self.gcn(p_simf, d_feat, adj_mat)
        p_feat_gcn_sim = self.gcn_p_sim(p_simf, p_simf)
        d_feat_gcn_sim = self.gcn_d_sim(d_feat, d_feat)
        
        x_ld = torch.vstack((p_feat_gcn,d_feat_gcn))
        x_ld_temp = torch.vstack((p_feat_gcn_sim,d_feat_gcn_sim))
        
        gcn_feat_merge = self.Multi_feat_merge(x_ld, x_ld_temp)
        
        p_feat_gcn_ = gcn_feat_merge[: p_feat_gcn.shape[0], :]
        d_feat_gcn_ = gcn_feat_merge[p_feat_gcn.shape[0] :, :]
        
        p_enc_outputs = self.p_encoder(p_feat_gcn_, d_feat_gcn_)
        d_enc_outputs = self.d_encoder(d_feat_gcn_, p_feat_gcn_)
        return self.predictor(p_enc_outputs, d_enc_outputs)
